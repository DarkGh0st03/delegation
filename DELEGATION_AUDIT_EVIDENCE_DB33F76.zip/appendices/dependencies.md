# Audit dipendenze e responsabilità effettive — main `db33f76`

## Stato e copertura

Fonte primaria: **`db33f76efa58900ddb869cef5fbe99c5a92bc9c7`**, snapshot read-only `/workspace/.audit-final/current`; elenco file e storia ottenuti con `git -C /workspace/delegation ls-tree/show` sullo SHA, non dall’HEAD del vecchio branch. **352 file tracciati**, inclusi `.github`, `.env.example`, manifest e placeholder. La baseline della run Gemini #5 rimane esclusivamente `02c3395b9111a63ccc9f441ea2c91c81865d6673`; il successivo refactor PR #14 non eredita automaticamente quella validazione paid. Nessun file repository, branch, commit, PR, workflow o risorsa esterna è stato modificato in questa analisi.

**Non è un semplice elenco di file senza import.** Ho ricostruito radici npm/workflow/CLI, import e re-export, chiamate a subprocessi, risorse caricate nell’app target, ownership delle dipendenze, consumer di simboli esportati, chiavi di configurazione e responsabilità operative. Ho distinto gli archi sintattici da quelli testuali: il grafo non considera un link documentale prova di uso runtime.

Risultati statici aggiornati:

- **196 moduli JS/TS analizzati dal parser Node 22.15.0** con `SourceTextModule` e stripping dei tipi, sempre in stato `unlinked`: nessun modulo è stato valutato, collegato a provider o avviato.
- **381 import/export runtime relativi**, tutti risolti; 817 specifier totali comprendendo built-in e package. Nessun import statico relativo mancante.
- **1.015 archi annotati** nel grafo, includendo npm/glob, workspace, Rust module, Solidity import, risorse e riferimenti testuali; quest’ultimo conteggio non è un numero di dipendenze runtime indipendenti.
- **9 manifest npm**, 3 grafi npm lock + Cargo lock corrente. Le dipendenze risolte e le versioni fanno parte del contratto; nessun install o aggiornamento è stato eseguito per questa sottoanalisi.
- Import dinamici esaminati manualmente: quattro URL di moduli dell’applicazione e `supertest` dentro la Researcher Acceptance; gli altri match sono commenti/stringhe fixture del checker. Le quattro URL si risolvono **dopo il montaggio nella copia IAM**, non rispetto al tree del framework.

Artefatti: `dependency-graph.json` (grafo, ownership package, env-name occurrence, export-simboli e confronto storico), `runtime-imports.json` (specifier reali del parser), `dependencies-candidates.csv` (sei campi richiesti), `generation-config-observation.json` (osservazione pura senza inference). Gli script di generazione restano fuori dalla repository. I conteggi delle suite effettive e le prove Docker del nuovo main appartengono al rapporto di validazione principale; non li deduco dal grafo.

## Che cosa è cambiato rispetto al precedente audit

Il confronto con il grafo `da769d09` non ripropone automaticamente le vecchie raccomandazioni. La coppia `adk-backend-live-probe.ts`/test è già stata eliminata: nessuna proposta di eliminarla di nuovo. Sono entrati helper di autorità negativa, acceptance negativa, suite backend indipendente, guardia import, test workflow Gitea, audit/documenti e ora **`compose-gitea.mjs`**. La vecchia conclusione “Gitea disposable avviata dallo script E2E” non descrive più main: PR #14 ha spostato creazione/teardown a Compose/workflow; gli script ora fanno preflight e inizializzazione applicativa.

L’aggregatore Phase12c era stato segnalato privo di caller automatico, ma il rapporto PR10 lo ha mantenuto intenzionalmente per rianalisi dei dati storici. Questa è una ragione concreta distinta dal runtime finale: **non lo riclassifico automaticamente come file da cancellare**. I `.gitkeep` ridondanti hanno beneficio trascurabile di rimozione e non costituiscono un problema architetturale; quelli `infra/env` e `infra/gitea` mantengono directory richieste dallo scaffold.

## Catena operativa e motivazione dei componenti

| Passaggio | Implementazione effettiva e responsabilità |
|---|---|
| Preparazione infrastruttura | I quattro workflow coordinator avviano Compose; `compose-gitea.mjs:11` verifica marker, container, label project/service, bind loopback e volume. Non avvia/ferma servizi. Lo script paid chiama preflight a:437; free a:426. |
| Gitea applicativa | `bootstrapGitea` nei due entrypoint principali (:235 paid/:224 free) importa il baseline, crea account/token, configura repository/protezione. È inizializzazione dell’applicazione su servizio esistente, non un secondo listener Gitea. La duplicazione di quelle procedure va confrontata nell’audit lifecycle; l’uso di entrambe in scenari separati non è prova di doppia istanza. |
| Software Engineer / root authority | `SoftwareEngineerAuthorityBootstrap` viene istanziato da paid:494/free:480; bootstrap CLI separato pubblicato in `@thesis/orchestrator` emette soltanto root DC e non esegue workflow completo. |
| Sequenza deterministica | `AccountSuspensionSequentialCoordinator` (:643 paid/:580 free), `workflow.ts` e `permission-templates.ts` impongono branch→Backend→Frontend→Test→PR, figli e permessi prefissati. Non viene istanziato `AdkAccountSuspensionOrchestrator` nel percorso canonico. |
| Trasporto A2A | `DelegatedA2ARoleRunner` e `DeterministicA2AOrchestrator` (:550-554 paid/:532-536 free) emettono DC figlia e gestiscono Agent Card, invio, polling, cancellazione e validazione dell’artefatto. I nomi “deterministic/Phase7” non rendono questi file mock. |
| Server ruolo | `server.ts:66-85` crea registry MCP privato, handler ADK, executor A2A e i due wrapper di privacy. Il medesimo executor gestisce task ADK e fallback di protocollo. |
| ADK/Gemini o scripted | `adk-a2a-handler.ts` costruisce un ADK Runner fresco per task, budget/timeout, cliente Gateway privato ed estrae risultati dai tool confermati. Il paid usa `createGeminiAdkModel`; il free usa `BaseLlm` scripted mantenendo stack ADK/A2A/MCP reale. |
| Shared MCP | `createSharedMcpHttpServer` (:507 paid/:493 free), `TaskRouter` e `task-token.ts` gestiscono quattro tool, JWT ruolo/task e routing verso worker. `src/main.ts` è alternativa CLI documentata, non un secondo server avviato dal medesimo workflow. |
| Worker privato | `private-mcp-task-registry.ts` verifica task attivo, token/JTI attuale, opt-in del tool e scope ruolo; conserva il Gateway client in closure. JWT routing e DC non sono lo stesso controllo. |
| Gateway → Rust → OPA | Gateway canonicalizza e prepara richiesta; `DelegationEvidenceHandler` ottiene VP firmata dall’Adapter; execute verifica autorizzazione Rust e decisione OPA prima del provider. La validazione frontend/worker non sostituisce questi confini. |
| DID/key backend | Il Core chiama Node tramite `DidEthrVerificationKeyProvider::resolve_document` (:46) con script configurabile, default Adapter `config.rs:82-83`; `evm_profile.rs:575` pubblica le chiavi. Il DID client è consumer subprocesso reale anche senza import TS. |
| Runner / acceptance | `IsolatedDockerRunnerExecutor` (:448 paid/:434 free) esegue SHA esatto, sei fasi progetto e suite researcher-owned montata separatamente. `backend-contract.spec.ts` importa dinamicamente i moduli della copia target per test indipendenti. |
| CI / Human Gate | `TrustedGiteaSecurityCi` (:718 paid/:682 free) usa executor privilegiato separato, pubblica status SHA; readiness (:748/:712) e trusted merge ricontrollano SHA/CI/review. La doppia esecuzione test è intenzionale indipendenza, non un costo da rimuovere come Gitea doppia. |

La costruzione dell’artefatto nel producer ADK e la sua validazione nel consumer RoleRunner/state-machine non sono duplicazioni accidentali: il consumer non deve fidarsi delle dichiarazioni remote. Ugualmente `PrivateEvidenceRequestHandler` sopprime history nelle risposte immediate, mentre `PrivateEvidenceTaskStore` agisce alla persistenza. Eliminare uno perché l’altro “toglie già la history” riapre un canale distinto.

## API con assenza di consumer interno accertata, ma ritiro da decidere (sezione C)

Gli ID DEP sono riferimenti locali da rimappare negli `AUD-00x` del rapporto unificato; le righe CSV separano esplicitamente “accertato” e “da decidere”. Nessuno dei riscontri sottostanti dimostra oggi un errore di autorizzazione o un secondo Gitea/MCP avviato dal medesimo percorso.

### DEP-001 — Due utility esportate senza alcun consumer interno: decisione C

**File e simboli:** `agent-runtime/src/artifact-builder.ts:8-22` — `buildLlmArtifactPayload`; `orchestrator-runtime/src/permission-templates.ts:238-246` — `repositoryPermissionUris`.

Evidenza più forte di un filename senza import: `git grep -w <simbolo> db33f76 --` produce **soltanto la definizione** per ciascuno. Nessun test, script, workflow, documentazione operativa, namespace import o dispatch per stringa ne nomina il simbolo. I barrel li espongono via `export *`, ma non costituiscono una chiamata. Il vecchio artifact builder trasforma `AgentControllerRunResult`; l’handler ADK finale costruisce invece il proprio artefatto a partire dalle operazioni Gateway confermate. L’helper URI restituisce due valori già ricavati internamente da funzioni private del template.

**Conseguenza:** due superfici API storiche senza responsabilità interna corrente. **Intervento futuro circoscritto:** rimuovere solo le due funzioni e l’import type `AgentControllerRunResult` diventato inutile; conservare `buildDeterministicArtifactPayload`, il modulo artifact e tutte le permission template. **Rischio:** basso internamente, da decidere per eventuali consumer esterni delle API esportate (package dichiarati `private`, non c’è inventario di consumer fuori repo). L’assenza di consumer interno è accertata; l’assenza universale di utenti esterni non viene inventata.

**Priorità:** bassa. **Validazione:** guardia import, tutte suite Node/permission scope/artifact e free E2E se si vuole confermare il percorso completo; nessuna variazione del payload Gemini necessaria. Questa è la proposta più piccola dimostrata, non una ragione per cancellare i file interi.

## Riscontri accertati di configurazione e contratti

### DEP-003 — Chiavi template senza reader

`poc/.env.example:10` assegna `GATEWAY_PORT`; il Gateway legge invece `GATEWAY_BIND_ADDR` (`config.ts:54`). A:19 assegna `ANVIL_RPC_URL`; il bootstrap trust legge `RPC_URL`. Una ricerca su tutti i file tracciati, inclusi hidden, trova per entrambi i nomi **una sola assegnazione nel template e nessun reader**. Non sono alias. Template e istruzioni non rappresentano il bootstrap `infra/.env` corrente; l’audit documentale dettaglia anche DNS di appservice assenti e mancato loader `.env`.

**Conseguenza:** impostazioni che sembrano configurare il PoC ma non fanno nulla. **Intervento:** riallineare o ritirare il template dopo aver scelto il launcher a cui è destinato, senza cambiare default reali. **Priorità:** media; **rischio:** basso per sola documentazione/config template. Questa anomalia è condivisa con il rapporto documentale, non va contata due volte.

### DEP-004 — `expected_revision` è un parametro effettivamente inerte dopo il controllo di forma

`orchestrator-runtime/src/a2a-workflow.ts:47` dichiara `expected_revision`; `issueAndRun` a:115 invoca `expectedRevision(input.expected_revision)` per validare la forma SHA, ma **non utilizza il valore validato**. Non lo trasmette all’issuer (:117-124), né alla richiesta A2A (:143-147), né a `validateWorkflowArtifact` (:149-154). Il coordinator lo prepara dal proprio stato a `sequential-coordinator.ts:188-214`, introducendo un passaggio contrattuale che non lega realmente la richiesta a quel valore.

**Prova effettiva già eseguita dal coordinatore dell’audit:** `/workspace/.audit-final/validation/expected-revision-probe.json`. Con due SHA validi distinti (`aaaa…` / `bbbb…`) sono identiche autorità emessa, richiesta A2A e risultato (`cccc…`); `passed:true`, `network_used:false`. Questa sottoanalisi ha letto tale evidenza e il codice, senza ripetere il test. Un valore malformato continua invece a essere respinto: non è un parametro totalmente ignorato dal parser, è il suo **valore semantico** a non incidere.

**Conseguenza:** API e nome suggeriscono una precondizione di revisione che quel livello non garantisce. **Non è una dimostrazione di bypass del controllo SHA**: Gateway/provider e i gate sul risultato/test/PR mantengono i propri controlli indipendenti; inoltre i ruoli scrivono legittimamente nuovi commit, quindi imporre banalmente `artifact.revision === expected_revision` sarebbe errato. Il workflow finale lega il PR head alla revisione testata (`workflow.ts:140-143`).

**Intervento consigliato, priorità media:** chiarire il contratto e decidere se rimuovere il campo/controllo di forma non operativo dai caller oppure implementare separatamente una precondizione di head iniziale realmente intesa. Non introdurre un nuovo vincolo di sicurezza come se fosse semplice cleanup. Rischio basso/medio per la rimozione del solo passaggio interno, maggiore per nuova semantica. Richiedere i test RoleRunner/coordinator/artifact/exact-SHA e free E2E; nessuna inference necessaria per accertare l’attuale no-op. Non è stato modificato alcun codice.

### DEP-005 — Express è usata direttamente da test/smoke del package Shared MCP, ma non dichiarata

`poc/mcp-shared/package.json:14-17` dichiara soltanto MCP SDK e Zod. Esistono invece cinque import **diretti** `express`: `scripts/real-read-smoke.mjs:12` e quattro test HTTP/worker a riga 5 (`mcp-create-http`, `mcp-write-http`, `mcp-run-tests-http`, `mcp-worker-bridge`). Sono consumer selezionati dagli script pubblicati `test` e `smoke:real`, non codice esemplificativo o stringhe generate.

**Situazione attuale:** Express è disponibile perché MCP SDK lo porta transitivamente; il lock standalone risolve 5.3.0. I test oggi passano: non si afferma una dipendenza mancante a runtime o un problema del server canonico. Il difetto accertato è che il manifest del package non descrive il proprio requisito diretto di sviluppo/smoke e dipende dalla presenza/accessibilità di una dipendenza di un altro package.

**Intervento consigliato, priorità media:** in un cambiamento autorizzato futuro dichiarare esplicitamente Express nel gruppo coerente con test/smoke, rispettando la versione già validata e aggiornando soltanto il contratto corrente necessario. Non introdurre una nuova major o un aggiornamento indiscriminato; non toccare i manifest/hash scientifici storici. Verificare install standalone, tutte suite MCP, `smoke:real` gratuito con prerequisiti reali e contratto di riproducibilità. Rischio contenuto ma non nullo: cambia metadata/lock hash, non serve una chiamata Gemini per validare questa dichiarazione.

## Residui con prova di inattività finale, ma decisione di scope necessaria

### Wrapper ADK dell’Orchestrator

`AdkAccountSuspensionOrchestrator` in `orchestrator-runtime/src/adk-orchestrator.ts` era chiamato da `phase10b-positive-e2e.mjs:27,673` al vecchio main `33abe0e6`; quel consumer e la sua guida sono stati rimossi. A `db33f76` rimangono definizione, **sei test propri**, export `index.ts:9` e dipendenze ADK/Zod di quel package. Nessun current CLI, workflow o E2E lo istanzia. Il paid/free finale chiama direttamente il coordinator deterministico.

Quindi è un **residuo architetturale concreto del vecchio percorso**, non un requisito del percorso Gemini attuale. Non lo dichiaro però cancellabile isolatamente: l’export è ancora un’interfaccia e il test prova il suo contratto. Per un PoC limitato all’architettura richiesta suggerisco una futura decisione esplicita di ritiro coeso **modulo + test della facciata + export + dipendenze del package eventualmente divenute superflue**. Non occorre toccare coordinator, authority, workflow o Human Gate. Rischio medio di API, costo di regressione gratuito. Se si decide invece che la facciata è un’estensione supportata, va descritta come tale e non come Orchestrator operativo. Un export da solo non dimostra utilità, così come non autorizza una rimozione non coordinata.

### OpenAI: compatibilità reale, non dipendenza del workflow finale

`apps/a2a-agent/src/main.ts:72-83` sceglie ancora OpenAI di default quando l’engine ADK è richiesto senza provider; pertanto `openai-adk-model.ts` **ha un caller operativo standalone**. Il client Responses non ADK `OpenAIResponsesClient` ha invece soltanto i propri test e il barrel export. Le classi e il package `openai` non sono istanziati dal canonico Gemini/free, ma il barrel ne carica i moduli quando si importa il runtime.

L’audit precedente aveva correttamente impedito la cancellazione isolata: questa conclusione resta valida. L’audit architetturale più profondo deve però mettere in discussione **la necessità di supportare ancora questo default alternativo**, non limitarsi a dire “esiste un ramo quindi serve per sempre”. Per il PoC strettamente Gemini suggerisco di valutare una migrazione mirata del bootstrap opzionale e il ritiro delle classi/provider test, preservando le interfacce `ModelClient`, `ModelFunction*` e il custom controller usato dalle prove Phase11. Rimuovere tutto `llm-client.ts`/`AgentController` romperebbe controlli attivi; togliere solo la dipendenza npm romperebbe subito i moduli esportati. Servono decisione d’interfaccia, nuova risoluzione lock/current contract e regressioni gratuite; nessuna chiamata OpenAI è giustificata.

### Doppio package/install Shared MCP

Il root `poc` comprende workspace `apps/*` e `packages/*`; `mcp-shared` è standalone con lock/install propri e CLI documentato. Root lock: 281 record; MCP lock: 96 record. Normalizzando i package a `(nome,versione)`, **tutte le 92 coppie uniche del lock MCP sono già nel lock root**. Nei workflow che installano entrambi esistono quindi copie fisiche sovrapposte dello stesso grafo e due contratti npm da mantenere.

La separazione è **giustificata dal package standalone documentato** e non dimostra una responsabilità duplicata per errore, né due Shared MCP server. Le 92 versioni sovrapposte non provano che il secondo install o il lock siano rimovibili. Un’eventuale integrazione workspace è soltanto una decisione C sul modello di distribuzione, sensata se si decide prima di ritirare l’indipendenza del package; non viene raccomandata come correzione necessaria prima della tesi. Inoltre test/smoke MCP importano Express direttamente (DEP-005), con risoluzione standalone 5.3.0 distinta dal root diretto 5.1.0. Peer/hoisting e quattro hash del contratto richiedono verifica. Nessun install o lock va tolto sulla sola base dell’overlap.

## Perché il vecchio runtime non è tutto obsoleto

`createSpecializedAgentController` è creato da `phase11a-identity-suspension-kill-switch.mjs:281`, `phase11b-identity-revocation-terminal.mjs:261` e `phase11c-status-commitment-mismatch.mjs:279`. Questi sono caller in script realmente selezionati da `phase11-security.yml`; usano un modello scripted per prove reali di revoca/status sulle autorizzazioni. Inoltre ADK importa `modelVisibleTaskContext` e profili/registry. La parte vecchia fornisce quindi **contratti e regressioni di sicurezza gratuiti ancora necessari**, anche se non è più il loop generativo della run Gemini.

Il controller custom e il runner ADK fanno entrambi loop tool/model, ma sono separabili solo dopo migrazione di quei consumer. Un ritiro indiscriminato perderebbe capacità di test senza rendere il modello più sicuro. `buildLlmArtifactPayload`, invece, non ha nemmeno questi consumer: è per questo che DEP-001 è più circoscritto e più forte.

## Proprietà/configurazioni e limiti della prova di inutilizzo

La scansione ha verificato gli accessi nominali `process.env`, chiamate `required/env::var` e riferimenti shell/YAML. Non ha letto né stampato valori dell’ambiente runtime o credential. Costruttori con chiavi dinamiche sono esaminati manualmente: token caller per ruolo, `MCP_<ROLE>_PUBLIC_KEY`, `MCP_<ROLE>_WORKER_URL` e timeout specifici. Non vengono classificati assenti solo perché manca un `process.env.NOME` letterale.

Le proprietà che compaiono una sola volta come campi JSON (Agent Card, telemetry, parametri SDK) **non sono automaticamente inutilizzate**: il consumer può essere esterno al repository. Non ho prodotto una lunga lista di falsi “unused props”. I casi problematici dimostrati sono le due chiavi senza reader del template e il valore `expected_revision` che dopo la validazione di forma non partecipa a nessuna operazione del RoleRunner (DEP-004). La proiezione intenzionale che omette `temperature` per Gemini 3.8 non viene classificata come configurazione inefficace o bug: è un adattamento esplicito da conservare (DEP-002, sezione D).

Il registry MCP cancella client/token alla fine del task; il distinto context store A2A salva DC e il suo `delete` non è invocato nel `finally` dell’executor (che elimina solo `#running`). Il percorso canonico ha processi effimeri; il CLI può durare più task. Questa osservazione di **retention/lifecycle** è inviata all’audit security: non propongo di cancellare il metodo `delete` perché “unused”, né cambio qui il contratto di retention osservato dai test.

## Ownership e dipendenze npm, package per package

| Manifest | Consumer / conclusione |
|---|---|
| `blockchain/did-client/package.json` | `ethers`, `did-resolver`, `ethr-did-resolver` hanno import reali e caller Rust via subprocesso; keep. |
| `poc/package.json` | Script infrastruttura/check/alias workspace. `@a2a-js/sdk` e `express` duplicano dichiarazioni del runtime, ma non producono due install della stessa versione all’interno del medesimo lock; root A2A è inoltre letto dal checker di riproducibilità. Migrazione dichiarazioni non è rimozione di file. |
| `apps/gateway` | Solo built-in Node; nessuna dipendenza npm diretta mancante/dichiarata inutile trovata. |
| `apps/test-runner-controller` | Solo built-in Node; Docker e toolchain della copia IAM sono dipendenze di runtime esterno, non npm mancanti del controller. |
| `apps/a2a-agent` | Importa `@thesis/agent-runtime`, CLI compatibilità e nove test bootstrap/tool flags; supportato, non avviato dal main in-process. |
| `apps/orchestrator` | Importa `@thesis/orchestrator-runtime`; CLI root-DC bootstrap distinto dalla sequenza deterministica. |
| `packages/agent-runtime` | A2A/ADK/Express/Zod/OpenAI importati realmente; MCP SDK è peer richiesto da ADK 2.2.1 anche senza un import diretto nello stesso package. OpenAI è candidato di scope, non attualmente unused. |
| `packages/orchestrator-runtime` | A2A è runtime del RoleRunner; agent-runtime fornisce contratti/API; ADK/Zod servono soltanto alla facciata opzionale esportata. Possibile snellimento con ritiro coeso della facciata. |
| `mcp-shared` | SDK/Zod runtime reali, `express` importato direttamente da quattro test e uno smoke e fornito transitivamente (DEP-005); package standalone esplicitamente documentato. Nessuna prova per rimuovere SDK/Zod. |

Il lock root contiene A2A **1.3.0** usato direttamente e **0.3.14** annidato in ADK; non sono copie intercambiabili per semplice deduplica. Contiene Express **5.1.0** diretto e **5.3.0** per MCP SDK, che richiede `^5.2.1`; non propongo aggiornamenti di versione per nascondere i due range. `@playwright/test` e l’import dinamico `supertest` della suite researcher appartengono all’applicazione IAM clonata: aggiungerli al framework per far sembrare completo un import scan sarebbe sbagliato.

## DEP-002 — Adattamento Gemini da conservare (sezione D)

L’entrypoint live a `a2a-production-coordinator-mcp-gemini-live.mjs:69-74` **documenta e applica intenzionalmente** la rimozione dei sampling parameter deprecati da Gemini 3.8: dal builder condiviso proietta `maxOutputTokens` e `thinkingConfig`, omettendo `temperature`. L’osservazione pura dei tre ruoli in `generation-config-observation.json` conferma il comportamento dichiarato; **non è evidenza di un bug, di configurazione errata, di copertura mancante o di duplicazione da correggere**. Builder e adattamento possono legittimamente servire contratti diversi. Non si propone unificare il builder o cambiare il payload del modello.

Resta soltanto materiale documentale da contestualizzare: il commento `gemini-thinking-policy.mjs:56-60` cita ancora il vecchio runner Phase10B e alcuni titoli dei test chiamano “actual” l’oggetto intermedio. L’eventuale aggiornamento di commento/titoli è di priorità bassa e confluisce nel gruppo di riferimenti storici imprecisi dell’audit documentale; non è un finding semantico autonomo. Preservare i test del builder e l’adattamento corrente, senza avviare inference o modificare il workflow paid.

## Componenti mantenuti e test protetti

Sono riconfermati necessari i tre script Gemini usati come fixture offline: health→metadata e backend-shape hanno import test diretti, guard CLI e fetch sintetico. Nessuno è stato avviato come probe remoto. I helper ripristinati `assert-current-authority-boundaries` e `assert-researcher-acceptance-negative` sono chiamati dal free E2E a:595 e:628; le suite backend indipendenti sono montate nel Runner. Non eliminare quei controlli solo perché il paid non chiama i due helper negativi.

Gli smokes MCP intermedi hanno alias npm ancora pubblicati, alcuni CLI manuali e test dedicati. Possono essere ridotti soltanto dopo confronto delle assertion e scelta di ritirare specifiche interfacce; l’assenza dal workflow finale non è prova sufficiente. Non vedo una motivazione per una grande pulizia automatica dei test in questo audit.

Il CSV allegato documenta anche falsi positivi da conservare: executor/deterministic artifact, due privacy wrapper, JWT/worker/Gateway, validazione producer/consumer, Runner/CI indipendenti, DID subprocesso, API CLI documentate, helper misurazioni e hash storici. Questo mantiene la complessità necessaria anziché chiamarla genericamente “duplicazione”.

## Verifiche effettive e conclusione limitata

Eseguiti in questa sottoanalisi: ricostruzione SHA352file, parsing statico196moduli/381importrelativi senza evaluation, verifica fixture dinamiche e risorse trasferite, proprietà manifest/lock, confronto della storia e dei consumer esportati, ricerca nominale completa anche nei file nascosti, controllo puro della configurazione Gemini per tre ruoli. Nessun install/build/provider/workflow è stato eseguito da questa sottoanalisi; le suite gratuite realmente avviate sono elencate dal coordinatore nel report generale.

Non affermo di aver enumerato tutti i consumer esterni delle API private ma esportate, né di aver verificato ogni possibile reflection futura o internale dei package vendor. La scansione raw `new URL/import type/import()` contiene sei apparenti assenze/alcuni match sintetici; sono esplicitamente annotate nel JSON, non presentate come sei bug: quattro URL sono risorse dell’app target e due stringhe sono fixture intenzionalmente mancanti.

**Valutazione:** i residui più significativi nel dominio TypeScript sono il wrapper ADK dell’Orchestrator rimasto senza il suo vecchio caller e la compatibilità OpenAI che è ancora selezionabile solo dal launcher secondario. Il primo è candidato di ritiro strutturale; la seconda richiede decidere l’ambito del PoC. Le due utility senza consumer interno restano decisioni di API; il template impreciso e il requisito Express non dichiarato sono interventi circoscritti con evidenza forte. L’adattamento sampling Gemini è intenzionale e va conservato. Il parametro expected_revision richiede chiarezza contrattuale, non un’asserzione di bypass. Il nucleo di A2A/ADK/MCP/Gateway e i test indipendenti hanno responsabilità distinte e giustificate. Non ho trovato in questo dominio una seconda istanza MCP/Orchestrator avviata inutilmente nello stesso flusso, né una motivazione per cancellare indiscriminatamente il vecchio controller o i test scripted.

Il lavoro autorizzato qui si arresta all’audit. Ogni futura rimozione/riallineamento deve essere scelto dal proprietario; nessun risultato paid viene esteso automaticamente al codice futuro.
