# Audit documentazione, storia e istruzioni operative — PR10–14

## A. Stato esaminato e copertura

Snapshot esaminato: `/workspace/.audit-final/current`, esattamente il commit **`db33f76efa58900ddb869cef5fbe99c5a92bc9c7`**, merge PR #14. Ho verificato localmente tutti i **352 blob tracciati** confrontando i byte dello snapshot con gli oggetti dell'albero Git `db33f76`: nessuna differenza. `snapshot-docs-provenance.json` registra il confronto. L'identificazione del vero HEAD remoto e le verifiche GitHub sono gestite dall'audit principale; questo sottotask non ha fatto richieste API.

La run Gemini autorevole indicata dall'utente è **`38761963415`**, commit **`02c3395b9111a63ccc9f441ea2c91c81865d6673`**, 15 ottobre 2026. Il codice corrente `db33f76` contiene una successiva modifica del lifecycle Compose/Gitea: non può ereditare la validazione pagata di 02c. Il successo delle regressioni gratuite PR #14 è dichiarato dall'utente; in questo sottotask non è stato verificato su GitHub né rieseguito.

Copertura documentale: letti tutti i **25 Markdown**, inclusi tutti i **12 README**, il template `poc/.env.example`, i manifesti sperimentali e il vecchio inventarioCSV 111 righe. Le descrizioni sono state confrontate con configurazioni, entrypoint, workflow e guardrail citati. Sono stati controllati **42 link Markdown locali:42 target esistenti,0 mancanti**. Non sono stati richiesti gli URL esterni per dichiararli verificati. Nessun file tracciato è stato modificato, nessun branch/commit/PR creato e nessun workflow/provider pagato avviato o modificato. Gli output sono esclusivamente fuori dalla repository.

### Responsabilità attuali dopoPR14

Per i quattro workflow coordinator esaminati, GitHub Actions prepara la sequenza e avvia **Gitea, OPA, Anvil con Compose**. Il workflow gratuito `shared-mcp-real-positive-e2e.yml:102-119` rifiuta un volume Gitea preesistente, avvia i tre servizi e verifica health. `compose-gitea.mjs:11-33` verifica flag `GITEA_E2E_COMPOSE_READY`, container in esecuzione, etichette progetto/servizio, binding e volume attesi. Lo script E2E gratuito `:426-431` usa il Gitea già avviato e inizializza repository, baseline, account, token e protezione applicativa. Non avvia o arresta il container. Il workflow possiede `down --volumes` nello step finale `:189-192`; lo script chiude socket/processi applicativi e log temporanei `:871-879`.

L'assegnazione infrastruttura/applicazione è esplicita nel README infrastruttura aggiornatoPR14`:9-15`. La Compose Gitea locale e `bootstrap-gitea.sh` restano per lo sviluppo e altre regressioni; non sono una seconda Gitea nel percorso coordinator corrente. Il flusso autorizzativo rimane Engineer/root DC→Orchestrator deterministico→A2A→tre ruoli ADK→Shared MCP→worker privato→Gateway→Rust/EVM/DID/status→OPA→Gitea/Runner→acceptance e CI indipendente→PR→human gate. La presenza dei vari verificatori non è duplicazione da eliminare.

## B. Problemi accertati

Gli ID `DOC-01…04` sono locali per l'integrazione nel rapporto principale, che può assegnare gli ID globali `AUD-xxx`. Le righe includono rischio e controlli necessari. Non propongo eliminazioni di evidenze o di documenti attuali basate soltanto su data/nome. Questi quattro gruppi hanno una contraddizione tecnica o una istruzione operativa concretamente non allineata; i miglioramenti opzionali sono separati sotto.

| ID | File/componente | Problema reale | Evidenza | Conseguenza | Intervento proposto | Priorità |
| --- | --- | --- | --- | --- | --- | --- |
| DOC-01 | poc/apps/gateway/README.md:22; poc/apps/test-runner-controller/README.md:30; poc/mcp-shared/README.md:34 | I README di componente non distinguono correttamente il riferimento più recente dalla precedente run: Gateway chiama final la run del13 ottobre, Runner la chiama the one verified real-Gemini run; MCP descrive soltanto quella precedente. | docs/CURRENT_CHECKPOINT.md:35-39 e README.md:38-40 distinguono run15 ottobre38761963415/02c3395b e run13 ottobre38379922436/9012c8c4. I tre README non sono stati aggiornati daPR13/14. | Chi segue le guide dei componenti incontra due risultati finali differenti e una falsa unicità; possibile attribuzione errata di review e codice generato. | Qualificare13 ottobre come risultato precedente e collegare CURRENT_CHECKPOINT per latest. Conservare entrambi gli SHA e la review del 13 come evidenza distinta. Rischio basso, solo testo; verificare link e confronto SHA. Nessuna API o nuova run necessaria. | Media |
| DOC-02 | poc/.env.example:1-20,29-30 | Template operativo residuo: invita a copiare un .env senza indicare un loader, contiene due nomi non letti e URL di app-service che non esistono nella Compose attuale. | GATEWAY_PORT (:10) e ANVIL_RPC_URL (:19) compaiono soltanto qui. Compose definisce gitea/opa/anvil, non delegation-adapter né test-runner-controller. gatewayConfigFromEnv legge GATEWAY_BIND_ADDR e altre variabili da process.env; nessun dotenv/loadEnvFile nel tree. I flussi reali usano init-local-env.mjs→poc/infra/.env e source esplicito. | Una guida apparentemente pronta all uso può far avviare il Gateway con configurazione mancante o DNS irraggiungibili e induce a mantenere parametri senza effetto. | Decidere se mantenere un template per CLI host o ritirare quello storico dopo aver verificato consumer esterni; se mantenuto, indicare percorso, caricamento esplicito, URL corretti e profilo supportato. Non aggiungere nuovi servizi per giustificare il template. Rischio basso per rimozione dei due nomi senza consumer interni; medio per intero file come interfaccia manuale. Test: presenza nomi, config parsing in env sintetico e avvio locale senza provider pagati. | Media |
| DOC-03 | poc/apps/gateway/README.md:31; poc/apps/test-runner-controller/README.md:16; relative config.ts | Descrizione della configurazione canonica esposta come vincolo di ogni avvio standalone: Gateway richiederebbe sempre Gitea/Runner; Runner richiederebbe sempre entrambe le suite. | Gateway config.ts:53 default mock, :70-82 richiede Adapter/OPA sempre e Gitea soltanto nel profilo non-mock; runtime.ts:39-55 seleziona mock o gitea-readonly. Runner config.ts:67-68 ammette TEST_RUNNER_ACCEPTANCE_ENABLED=false; E2E reale db33:439 e live db33:453 fissano acceptance_enabled:true. | Le guide nascondono profili ancora supportati e non distinguono la garanzia dell esperimento finale dalla configurabilità del servizio generico. | Specificare il profilo canonico gitea+Runner+acceptance e documentare separatamente gli altri profili. Non rimuovere opzioni, mock o test come se fossero morti. Rischio basso per testo, medio/alto per modifica dell interfaccia. Test: confronto config/README e suite config; nessuna generazione pagata. | Media |
| DOC-04 | poc/apps/a2a-agent/src/main.ts:93 | Il commento afferma che tutti gli attuali workflow restano su local FunctionTools; descrive una fase precedente anziché il solo launcher standalone. | Il codice :94-112 riguarda MCP opt-in del CLI. I percorsi canonici db33 importano e avviano createSharedMcpHttpServer; README a2a:5-15 distingue correttamente launcher opzionale e percorso Shared MCP. | Un lettore può dedurre erroneamente che lo Shared MCP non sia nel percorso operativo finale. | Limitare il commento al launcher standalone e rimandare al coordinatore canonico. Rischio trascurabile per commento; verifica diff e ricerca della frase. Non eliminare FunctionTools, API o compatibilità senza decisione separata. | Bassa |

### Dettaglio del template `.env`

Il template non è il file generato/letto dal percorso corrente. `init-local-env.mjs` scrive `poc/infra/.env`; script locali e workflow lo caricano con `source` o lo passano alla Compose. Nessun comando tracciato carica automaticamente `poc/.env`; non esiste `dotenv`/`loadEnvFile` nel codice applicativo. Il template indica `http://delegation-adapter:8090` e `http://test-runner-controller:8095`, ma la Compose definisce soltanto i tre servizi infrastrutturali. Quegli URL potrebbero appartenere a un deployment esterno non documentato; il tree non ne fornisce uno. Le due variabili `GATEWAY_PORT` e `ANVIL_RPC_URL` non hanno reader interni. Questa è evidenza di scaffold arretrato, non ragione per aggiungere container applicativi non richiesti.

Prima di cancellare l'intero template, verificare se esista un uso manuale esterno ancora intenzionale. In alternativa, mantenerlo come esempio host CLI con nome del file, modalità esplicita di esportazione e parametri realmente supportati. La scelta non richiede né permette una chiamata Gemini.

## C. Casi possibili, opzionali o da decidere

1. **Stato correntePR14 e fotografia della run02c.** `CURRENT_CHECKPOINT.md:35` descrive il setupPR12 usato dalla run pagata; non va riscritto per far credere che quella run abbia usato Compose GiteaPR14. Il README infrastruttura è oggi la fonte del lifecycle corrente, e`:15` dichiara che02c resta l'ultimo paid-tested SHA. Un breve rinvio operativo in CURRENT_CHECKPOINT/runbook può ridurre ambiguità, ma la prova storica della run deve restare invariata. Non considero il racconto storicoPR12 un difetto del runtime corrente.
2. **Quick checksREADME rispetto all'interaCI.** `README.md:59-70` elenca un sottoinsieme valido delle verifiche; `poc-baseline.yml:39,46,51,53` aggiunge `--all-features`, import guard, A2A e test script. Non è dichiarato che ilREADME sia una suite esaustiva, quindi non lo classifico come errore accertato. Può essere utile chiamarlo “subset” o collegare il workflow come lista completa. Non togliere test per far coincidere la guida.
3. **Osservazione GitHub amministrativa.** `CURRENT_CHECKPOINT.md:51` eredita `main.protected=false` e ruleset vuoto da un checkpoint precedente. Git non prova che tali impostazioni siano ancora vere. Occorre datare quella osservazione o verificarla separatamente; qui non viene affermato lo stato remoto corrente.
4. **CLI trust manuale.** `blockchain/scripts/run-pre-gateway-local.sh:7,63,192-193` assume `.git` directory e termina con shell interattiva. È documentato come regressione trust persistente; non è un runner generale cloud. Un checkout con `.git`file richiede una scelta esplicita di compatibilità e test isolato. Non propongo di rimuoverlo: conserva una prova indipendente EVM/status ancora supportata.
5. **Interfacce opzionali.** A2A standalone seleziona ancora deterministic/ADK, OpenAI/Gemini e FunctionTools/MCP; Gateway seleziona mock/read-only/full; Runner può disabilitare acceptance fuori dal canonico. Sono consumer/configurazioni effettive, non file isolati senza uso. Decidere se supportarli o deprecarli precede qualsiasi rimozione; tali cambiamenti vanno oltre una correzione doc.
6. **Toolmeasurement storici.** Phase 12A rimane richiesto dal checker corrente soltanto per riconoscere lo schema; Phase 12C è una CLI manuale di rianalisi5×28. Separare l'archivio dallo schema corrente potrebbe semplificare i confini, ma rimuoverli adesso rompeCI o rianalisi. Serve una migrazione esplicita, senza riscrivere i risultati.
7. **GuardrailPR14 statico e dinamico.** Il test `single-disposable-gitea-workflows.test.mjs:18-52` verifica testo di quattro workflow, quattro script e Compose; il preflight esegue `docker inspect`. Queste prove hanno scopi diversi. Non descrivere il solo test regex come misurazione dinamica del numero di container. L'audit principale valuta separatamente il Docker E2E e il ciclo di vita reale.

## D. Storia e componenti da conservare

### RicostruzionePR10–14

| Evoluzione | Commit | Conclusione da Git locale |
| --- | --- | --- |
| PR #11 nel branch PR #10 | `f9ad77a48c9281a5ec6f94be41f603bd8671987f` | Recupera i guardrail `d9a9b5e` e report `8ca0ca8` prima del mergePR10. |
| PR #10 in main | `7e5f4460498f8e34ced413965cc1a63126597c43` | Pulizia e controlli indipendenti recuperati entrano insieme. |
| PR12 | `02c3395b9111a63ccc9f441ea2c91c81865d6673` | Elimina Compose Gitea inutilizzata nei job che allora creavano Gitea negli E2E; questo è il setup della run pagata5. |
| PR13 | `50c098db5880b755db23998ef509613efdbb45f5` | Diff da02c:7 Markdown, nessun cambiamento runtime/config. È documentazione della run, non nuova esecuzione E2E. |
| PR14 | `db33f76efa58900ddb869cef5fbe99c5a92bc9c7` |11 file cambiati rispetto a50c:4 workflow,4 script E2E, helper Compose, test di regressione,README infrastruttura. Compose ora gestisce infrastruttura; script applicativi inizializzano la repository. Non è una modifica soltanto documentale. |

I messaggi di merge riferiscono checkgreen; sono metadatiGit e non sostituiscono verificaAPI o nuove esecuzioni. L'utente riferisce successo delle verifiche gratuite PR #14. Nessun paidPASS di 02c viene attribuito a db33.

### Vecchio audit e111 decisioni

`PR10_TECHNICAL_AUDIT.md` e `audit/pr10-file-decisions.csv` sono identici byteperbyte alla revisione8ca0ca8. Tutti i111 file censiti mantengono la stessa presenza e nessuno di questi111 path è cambiato tra 8ca e db33. Distribuzione attuale:64 rimossi (62PR10+2PR11),28 necessari presenti,11 storici usati presenti,4 da verificare presenti,4 `.gitkeep` classificati obsoleti ma conservati intenzionalmente. `old-audit-111-recheck.csv` documenta la ricognizione senza cambiare ilCSVoriginale.

La riga CSV 110 dice ancora che gemini-thinking-policy non è selezionato dallaCI: è un'affermazione della situazione precedente al ripristino, ormai superata dal glob `poc/scripts/test/*.test.mjs` nel baseline`:53`. Preservare lo snapshot e registrare il delta nel nuovo rapporto; non trattarlo come bug corrente né riscrivere la prova. Le linee di proof sono riferite al vecchio SHA e possono non coincidere con le linee attuali.

L'inventario non conteneva righe dei quattro workflow mantenuti modificatiPR12/14, né il nuovo helperCompose. Quindi le sue decisioni non dimostrano completezza dell'ownership infrastrutturale corrente. I riferimenti ai path cancellati nelCSV/report sono evidenza intenzionale, non import mancanti runtime.

### Responsabilità distinte da proteggere

- `ARCHITECTURE_DECISIONS` e `IMPLEMENTATION_STATE` sono anche richiesti da scaffold e spiegano decisioni e mappa del codice. CURRENT_CHECKPOINT contiene prove/stato, non la stessa responsabilità. Nessuna cancellazione per somiglianza dei titoli.
- Evidenze13 ottobre e15 ottobre, reviewdei11 file13, campagna storicacbad e relativi manifesti/summary restano separati. La review del 13 non vale per l'output15.
- Il manualehuman merge e il relativo CLI privilegiato non sono una seconda toolAPIagentica: restano fuori dagli agent tools, con identità/review/CI separate. Non devono essere eseguiti per questo audit.
- Researcher acceptance e Security CI non sono duplicati di `run_tests` del Test Agent. I loro confini indipendenti giustificano esecuzioni separate, positive e negative.
- Bootstrap root DC standalone usa la medesima classe trusted impiegata in processo dagli E2E; non costituisce un altro Orchestrator. Il launcherMCP standalone usa lo stesso server in un diverso hosting; non dimostra due MCP nello stesso workflow.
- Gli alias npm dei smoke MCP/A2A sono entrypoint manualmente supportati. La mancanza di un workflow dedicato non basta per eliminarli.
- Le fixture Gemini importate dai test offline vanno conservate. I rami CLI possono chiamare provider, quindi non sono stati avviati.
- `PRE_GATEWAY_CHECKPOINT` è già marcato storico e rimanda all'architettura corrente. Non riproporre come bug aperto il vecchio titolo/freeze già correttoPR11.

### Integrità delle evidenze storiche

Confrontati localmente con 33abe0e e rimasti identici: evidenza Gemini del 13, review del 13, risultati delle misure, manifesto storico e reference-summary. Confrontati con 8ca e identici: rapporto PR #10 eCSV 111. `historical-evidence-integrity.json` contiene SHA256 e provenienza di tutti e 7.

Il manifesto storico resta SHA256 `c4fe6a0f0cfbd71b0e4b9d764d8c2d3fdab1c36c5536b95a81de96d9cc3551bb`; eliminarlo o riscriverlo rompe la verifica del contratto corrente. La baseline esterna `iam-console-poc` resta `405748b1e77992b6bd8630a3ab6f990658d32f6b`, mai modificata da questo sottotask.

Il documento15 ottobre dichiara digest GitHub del ZIP ma non download/review indipendente dei byte durante PR #13. Un sommario non è un archivio completo. Eventuale recupero delle evidenze deve conservareZIPoriginali e checksum distinti, non rigenerare output con una nuova chiamata pagata. Nessun download/API è stato effettuato qui.

## E. Piano consigliato, senza applicazione

**Priorità media:** correggere i riferimenti finali/unici delle guide di componente e decidere il destino del template `.env` residuo; chiarire i profili generici contro la configurazione canonica. Sono interventi con prove gratuite possibili, senza cambiare protocolli, policy o provider.

**Priorità bassa:** correggere il commentoFunctionTools, migliorare collegamenti verso la fonte latest e precisare il sottoinsieme quick checks. I miglioramenti solo estetici, il numero di file e la lunghezza dei documenti non sono una motivazione sufficiente.

**Decisione separata:** deprecazione degli entrypoint alternativi, rimozione di opzioni runtime, consolidamento di bootstrap applicativi e modifica del legame con gli strumenti storici. Servono consumer map e regressioni funzionali. Qualsiasi futura modifica al path live sarebbe un nuovo codice da valutare autonomamente: il riferimento pagato02c non si trasferisce. Il presente audit non richiede né autorizza un'altra validazione Gemini.

## F. Valutazione complessiva del sottotask

La documentazione principale è sostanzialmente coerente con i confini del PoC; PR #11 ha già risolto le grandi contraddizioni ADR/GPT/Orchestrator e PR #14 ha aggiornato il README infrastruttura sul vero lifecycle. I residui documentali accertati hanno impatto operativo o di attribuzione concreto ma sono circoscritti. Non ho trovato una ragione per cancellare materiale scientifico, guide dei componenti o runbook privilegiati.

Esistono ancora percorsi alternativi supportati e un template di configurazione arretrato; la loro presenza non dimostra da sola una seconda Gitea o un secondoMCP attivo. Su questo perimetro, la nuova ownershipPR14 è leggibile e verificabile, mentre una dichiarazione di assenza di altre ridondanze richiede l'audit runtime/infrastruttura principale. Questo report non pretende di aver eseguito o verificato l'intero software.

Verifiche realmente svolte: confronto352 blob, lettura25 Markdown/12 README, controllo42 target locali, ricognizione111 decisioni,7 confronti byte storici, storiaPR10–14 e config/entrypoint/workflow citati. Nessuna suite applicativa, Docker E2E o GitHub Action è stata eseguita da questo sottotask. Nessun file tracciato, branch, commit,PR o risorsa esterna è stato modificato.
